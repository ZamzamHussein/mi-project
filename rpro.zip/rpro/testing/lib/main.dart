import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("welcome to flutter"),
        ),
        body: Center(
          child: Image(
            image: AssetImage('imges/image1.png'),
          ),
          Image(
            image: AssetImage('imges/pic6.jpg'),
          ),
          Image(
            image: AssetImage('imges/pic7.jpg'),
          ),
        ),
      ),
    ),
  );
}
